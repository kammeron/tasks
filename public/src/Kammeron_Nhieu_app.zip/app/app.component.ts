import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Restful Tasks API';
  tasksAll:any = [];
  tasksToDo: any = [];
  tasksComplete: any = [];
  currentTask: object;
  newTask: any;
  constructor(private _httpService: HttpService){};
  ngOnInit(){
      this.newTask = { title: "", description: "" };
  }
  getTasksFromService(){
  	let observable = this._httpService.getTasks();
  	observable.subscribe(data => {
  		this.tasksAll = data
  		for (let i of this.tasksAll) {
  			if (i.completed == true) {
  				this.tasksComplete.push(i)
  			}
            else {
  				this.tasksToDo.push(i)
  			}
  		}
  	});
  }
  getTaskById(_id){
      let observable = this._httpService.getTaskById(_id);
      observable.subscribe(data => {
          this.currentTask = data;
      });
  }
  deleteTask(_id){
      let observable = this._httpService.delete(_id);
      observable.subscribe();
      this.getTasksFromService();
  }
  editTask(_id){
      this.getTaskById(_id);
      let observable = this._httpService.edit(_id);
      observable.subscribe(data => {
          console.log(data)
          this.getTasksFromService();
      })
  }
  onSubmit(){
      let observable = this._httpService.create(this.newTask);
      observable.subscribe(data => {
          this.getTasksFromService();
          this.newTask = { title: "", description: "" };
      });
  }
  onEdit(){
      console.log(this.currentTask)
      // let observable = this._httpService.edit(this.currentTask);
      // observable.subscribe(data => {
      //     this.getTasksFromService();
      //     this.currentTask = [];
      // })
  }
}
